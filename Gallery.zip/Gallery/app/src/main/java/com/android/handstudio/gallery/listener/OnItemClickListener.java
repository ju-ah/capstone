package com.android.handstudio.gallery.listener;

import com.android.handstudio.gallery.adapter.GalleryAdapter;

/**
 * Created by woong on 2015. 10. 20..
 */
public interface OnItemClickListener {

    void OnItemClick(GalleryAdapter.PhotoViewHolder photoViewHolder , int position);
}
